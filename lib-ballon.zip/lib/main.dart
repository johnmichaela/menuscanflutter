import 'package:ballon/core/services/services_locator.dart';
import 'package:ballon/typeapp_state.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app_state.dart';
import 'screens.dart';
import 'package:firebase_core/firebase_core.dart';
import 'services/notification_service.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp();
  
  // Initialize Notification Service
  await NotificationService.initialize();
  AppServiceLocator.initAppServiceLocator();
  runApp(const BalloonApp());
}

class BalloonApp extends StatelessWidget {
  const BalloonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return  MultiProvider(
  providers: [
    ChangeNotifierProvider(
      create: (_) => AppState(),
    ),
    ChangeNotifierProvider(
      create: (_) => AppStateType(),
    ),
  ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Balloon',
        theme: ThemeData(
          useMaterial3: true,
          primaryColor: const Color(0xFFE71D36),
          scaffoldBackgroundColor: const Color(0xFFF5F5F7),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFFE71D36),
            primary: const Color(0xFFE71D36),
          ),
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
